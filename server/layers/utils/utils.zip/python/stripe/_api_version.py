# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
class _ApiVersion:
    CURRENT = "2025-11-17.clover"
    CURRENT_MAJOR = "clover"
