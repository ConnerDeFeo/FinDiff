# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from typing_extensions import TypedDict


class AccountExternalAccountDeleteParams(TypedDict):
    pass
